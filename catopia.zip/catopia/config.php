<?php

//connect to catopia database

//if($server['HTTP_HOST'] == "catopia.club")
//{
    //define('SERVER', 'localhost');
    //define('USER', 'kendraj0_cat');
    //define('PW', 'cat123456');
    //define('DB', 'kendraj0_cat');


//localhost
    define('SERVER', 'localhost');
    define('USER', 'cat');
    define('PW', '123456');
    define('DB', 'catopia');

